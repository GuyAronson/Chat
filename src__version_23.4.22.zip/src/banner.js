import React from 'react';
import ReactDOM from 'react-dom/client';

class Banner extends React.Component{
    render(){
        return (
        <><div id="top-container">
        <div id="logo">
            <div id="logo-circle"></div>
            <h1><span>Talk</span><br />
                <span>to</span><br />
                <span>me</span><br />
                <span>Bro</span>
            </h1>
        </div>
        </div></>
        );
    }
}
export default Banner;
